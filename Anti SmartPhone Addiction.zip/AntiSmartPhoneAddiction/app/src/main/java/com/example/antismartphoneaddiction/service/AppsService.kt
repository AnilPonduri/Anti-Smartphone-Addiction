package com.example.antismartphoneaddiction.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.*
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.*
import com.example.antismartphoneaddiction.db.AppsDatabase
import com.example.antismartphoneaddiction.db.DbAppItem
import com.example.antismartphoneaddiction.repository.AppItemsRepository
import com.example.antismartphoneaddiction.utils.AppUtil
import java.lang.Exception

class AppsService : LifecycleService() {
    lateinit var  allUptimes: LiveData<List<DbAppItem>>
    private lateinit var repository: AppItemsRepository
    private lateinit var localList: List<DbAppItem>
    private var localListHashMap: HashMap<String, Long> = HashMap()

    init {


    }

    override fun onCreate() {

        super.onCreate()
        val appsDao = AppsDatabase.getInstance(this, lifecycleScope)
            .appsDao()
        repository = AppItemsRepository(appsDao)
        allUptimes = repository.allUptimes

        allUptimes.observeForever( Observer { uptimesList ->
            uptimesList?.let {
                localList = it
                localList.forEach { item ->
                    localListHashMap[item.appPackageName] = item.upTime!!
                }
            }

        })
    }

    val thread: Thread = Thread(Runnable {
        getCurrentForeGroundApp()
    })

    private fun getCurrentForeGroundApp() {
        while (true) {
            try {
                Thread.sleep(30000)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }

            Log.d("Background service", "Inside onstart")
            var currentApp: String? = AppUtil.getCurrentForeGroundApp(this)
            if (localListHashMap.containsKey(currentApp)){
                var timeAlreadySpent = AppUtil.getTotalForeGroundTimeForSpecificApp(currentApp, this);

                if (timeAlreadySpent.compareTo(localListHashMap[currentApp]!!) > 0) {
                    Handler(Looper.getMainLooper()).post{
                        Toast.makeText(this, "You've used this app for longer than you resolved to.", Toast.LENGTH_LONG).show()
                    }

                    val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                    vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
                   Log.d("Background service", "THis app has already spent more time than was allocated")
                }

            }else{

            }
            //Thread.currentThread().interrupt()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        onTaskRemoved(intent)
        try {
            thread.start()
        } catch (e: Exception) {
            // e.printStackTrace()
        }
        val CHANNEL_ID = "Anti Addiction Channel ID"
        var channel: NotificationChannel =
            NotificationChannel(CHANNEL_ID, CHANNEL_ID, NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        var builder: Notification.Builder = Notification.Builder(this, CHANNEL_ID)
            .setContentText("Anti Addiction Service is running")
            .setContentTitle("Anti Smartphone Addiction")

        startForeground(10001, builder.build())
        return START_STICKY

    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val restartServiceIntent = Intent(applicationContext, this.javaClass)
        restartServiceIntent.setPackage(packageName)
        startService(restartServiceIntent)
        super.onTaskRemoved(rootIntent)
    }
}
package com.example.antismartphoneaddiction.db

import androidx.annotation.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "db_app_item")
class DbAppItem(@PrimaryKey var appPackageName:String ="", val upTime:Long? = Long.MAX_VALUE){

}

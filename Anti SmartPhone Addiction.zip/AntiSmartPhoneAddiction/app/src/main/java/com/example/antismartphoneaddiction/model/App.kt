package com.example.antismartphoneaddiction.model

data class App(val appName:String, val packageName:String, var isSystem:Boolean, var usageTime:String , var usagePercentage:Int)

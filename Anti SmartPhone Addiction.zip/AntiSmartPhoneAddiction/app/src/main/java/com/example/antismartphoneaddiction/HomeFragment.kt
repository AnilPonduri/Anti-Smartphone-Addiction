package com.example.antismartphoneaddiction

import android.app.AlertDialog
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context.USAGE_STATS_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.antismartphoneaddiction.databinding.FragmentHomeBinding
import com.example.antismartphoneaddiction.db.DbAppItem
import com.example.antismartphoneaddiction.model.App
import com.example.antismartphoneaddiction.service.AppsService
import com.example.antismartphoneaddiction.utils.AppItemsAdapter
import com.example.antismartphoneaddiction.utils.AppUtil
import com.example.antismartphoneaddiction.utils.ClickListener
import com.example.antismartphoneaddiction.viewmodels.HomeViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.lang.IllegalArgumentException
import java.util.concurrent.TimeUnit


class HomeFragment : Fragment() {
    private lateinit var fragmentHomeBinding: FragmentHomeBinding
    private lateinit var viewModel: HomeViewModel
    private lateinit var localList: List<DbAppItem>
    private var localListHashMap: HashMap<String, Long> = HashMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fragmentHomeBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)
        viewModel = ViewModelProvider(this).get(HomeViewModel::class.java)
        viewModel.allUptimes.observe(viewLifecycleOwner, Observer { uptimesList ->
            uptimesList?.let {
                localList = it
                Log.d("Foreground service", "Uptimes updated: ${localList.size}")
                localList.forEach { item ->
                    localListHashMap[item.appPackageName] = item.upTime!!
                }
            }
        })
        return fragmentHomeBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val layoutManager = LinearLayoutManager(requireContext())
        val adapter = AppItemsAdapter(ClickListener { app ->
            showTimePickDialog(app.packageName)
        })

        fragmentHomeBinding.recyclerViewApps.adapter = adapter
        fragmentHomeBinding.recyclerViewApps.layoutManager = layoutManager
        var appsList: List<UsageStats> =
           AppUtil.loadApps(requireContext()).sortedWith(compareByDescending({ it.totalTimeInForeground }))
        var finalAppsList = ArrayList<App>()

        var totalTime = appsList.sumOf { it.totalTimeInForeground }

        for (usageStats in appsList) {
            try {
                var packageName = usageStats.packageName
                var packageNames = packageName.split("\\.")
                var appName = packageNames[packageNames.size - 1].trim()
                if (isAppInfoAvailable(usageStats)) {
                    var ai = requireContext().packageManager.getApplicationInfo(packageName, 0)
                    appName = requireContext().packageManager.getApplicationLabel(ai).toString()

                }
                var usageDuration = getDuration(usageStats.totalTimeInForeground)
                var usagePercentage = ((usageStats.totalTimeInForeground * 100) / totalTime).toInt()

                var app: App = App(appName, packageName, false, usageDuration, usagePercentage)
                finalAppsList.add(app)

            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
        }

        adapter.submitList(finalAppsList)


    }

    fun getDuration(_millis: Long): String {
        var millis = _millis

        if (_millis < 0) {
            throw IllegalArgumentException("Duration must be greater than zero!")
        }
        var hours: Long = TimeUnit.MILLISECONDS.toHours(_millis)
        millis -= TimeUnit.HOURS.toMillis(hours)
        var minutes: Long = TimeUnit.MILLISECONDS.toMinutes(millis)
        millis -= TimeUnit.MINUTES.toMillis(minutes)
        var seconds: Long = TimeUnit.MILLISECONDS.toSeconds(millis)

        return "$hours h $minutes m : $seconds s"

    }

    fun isAppInfoAvailable(usageStats: UsageStats): Boolean {
        return try {
            requireContext().packageManager.getApplicationInfo(usageStats.packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }



    fun showTimePickDialog(appPackageName: String) {

        val builder = AlertDialog.Builder(requireContext())
        val inflater:LayoutInflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.edit_allowed_time_layout, null)
        val editTextHours = dialogLayout.findViewById<EditText>(R.id.editTextHours)
        val editTextMinutes = dialogLayout.findViewById<EditText>(R.id.editTextMinutes)

        with(builder){
            if (localListHashMap.containsKey(appPackageName)) {
                //app is already in database
                var upTime = localListHashMap[appPackageName]
                var hours:Long = TimeUnit.MILLISECONDS.toHours(upTime!!)
                upTime-=TimeUnit.HOURS.toMillis(hours)
                var minutes = TimeUnit.MILLISECONDS.toMinutes(upTime)
                editTextHours.setText(hours.toString())
                editTextMinutes.setText(minutes.toString())

            }
            setPositiveButton("SAVE"){dialog, _ ->
                if (editTextHours.text.toString().isNotEmpty() && editTextMinutes.text.toString().isNotEmpty() && editTextHours.text.toString().toInt() < 24
                    && editTextHours.text.toString().toInt() >= 0 && editTextMinutes.text.toString().toInt() < 60 && editTextMinutes.text.toString().toInt() >= 0
                ) {
                    var upTimeAsLong: Long =
                        TimeUnit.HOURS.toMillis(editTextHours.text.toString().toLong())
                    upTimeAsLong += (TimeUnit.MINUTES.toMillis(
                        editTextMinutes.text.toString().toLong()
                    ))
                    CoroutineScope(Dispatchers.Main).launch {
                        withContext(Dispatchers.IO) {
                            var appItem = DbAppItem(appPackageName, upTimeAsLong)
                            viewModel.insert(appItem)
                        }
                    }
                    Toast.makeText(requireContext(), "Time saved succesfully", Toast.LENGTH_LONG).show()
                }

            }
            setNegativeButton("CANCEL"){dialog, _ ->

            }
            setView(dialogLayout)
            show()

        }
    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            HomeFragment().apply {

            }
    }
}
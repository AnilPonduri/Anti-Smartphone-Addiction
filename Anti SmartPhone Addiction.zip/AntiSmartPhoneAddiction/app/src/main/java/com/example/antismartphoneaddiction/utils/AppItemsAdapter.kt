package com.example.antismartphoneaddiction.utils

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.antismartphoneaddiction.databinding.IndividualItemBinding
import com.example.antismartphoneaddiction.model.App


class AppItemsDiffCallBack : DiffUtil.ItemCallback<App>() {
    override fun areItemsTheSame(oldItem: App, newItem: App): Boolean {
        return newItem == oldItem
    }

    override fun areContentsTheSame(oldItem: App, newItem: App): Boolean {
        return newItem.equals(oldItem)
    }

}

class AppItemsAdapter(val clickListener: ClickListener) :
    ListAdapter<App, AppItemsAdapter.AppsViewHolder>(AppItemsDiffCallBack()) {


    inner class AppsViewHolder(val binding: IndividualItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(app: App, clickListener: ClickListener) {
            binding.app = app;
            binding.clickListener = clickListener
            binding.appName.text = app.appName
            Glide.with(binding.root.context)
                .load(AppUtil.getPackageIcon(binding.root.context, app.packageName))
                .into(binding.appIcon)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppsViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = IndividualItemBinding.inflate(layoutInflater, parent, false)
        return AppsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppsViewHolder, position: Int) {
        val item = getItem(position)

        return holder.bind(item, clickListener)
    }

    override fun getItemId(position: Int): Long {
        return super.getItemId(position)
    }
}

class ClickListener(val clickListener: (item: App) -> Unit) {
    fun onClick(item: App) = clickListener(item)
}
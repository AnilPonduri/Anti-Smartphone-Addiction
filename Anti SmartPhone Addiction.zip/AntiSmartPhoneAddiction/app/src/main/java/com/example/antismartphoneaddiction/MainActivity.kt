package com.example.antismartphoneaddiction

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.antismartphoneaddiction.service.AppsService

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.startForegroundService(Intent(this, AppsService::class.java))
        //requireActivity().startService(Intent(requireContext(), AppsService::class.java));
    }
}
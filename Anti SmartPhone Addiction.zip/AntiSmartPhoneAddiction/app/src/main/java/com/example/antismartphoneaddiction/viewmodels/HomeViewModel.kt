package com.example.antismartphoneaddiction.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.antismartphoneaddiction.db.AppsDatabase
import com.example.antismartphoneaddiction.db.DbAppItem
import com.example.antismartphoneaddiction.repository.AppItemsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HomeViewModel(application: Application):AndroidViewModel(application) {
    val allUptimes:LiveData<List<DbAppItem>>
    private val repository: AppItemsRepository

    init {
        val appsDao = AppsDatabase.getInstance(application.applicationContext, viewModelScope)
            .appsDao()
        repository = AppItemsRepository(appsDao)
        allUptimes = repository.allUptimes
    }
    suspend fun insert(dbAppItem: DbAppItem){
        viewModelScope.launch ( Dispatchers.IO ){
            repository.insert(dbAppItem)
        }
    }

}
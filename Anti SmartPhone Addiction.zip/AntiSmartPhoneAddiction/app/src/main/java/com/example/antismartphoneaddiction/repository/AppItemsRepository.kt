package com.example.antismartphoneaddiction.repository

import androidx.lifecycle.LiveData
import com.example.antismartphoneaddiction.db.AppsDao
import com.example.antismartphoneaddiction.db.DbAppItem

class AppItemsRepository(val dao:AppsDao) {
    var allUptimes:LiveData<List<DbAppItem>> = dao.getAllUptimes()

    suspend fun insert(dbAppItem: DbAppItem){
        dao.insert(dbAppItem)
    }

}
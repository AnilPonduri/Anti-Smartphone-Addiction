package com.example.antismartphoneaddiction.utils;

import android.app.ActivityManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.example.antismartphoneaddiction.R;

import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import static android.content.Context.USAGE_STATS_SERVICE;

public class AppUtil {

    public static Drawable getPackageIcon(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        try {
            return packageManager.getApplicationIcon(packageName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return context.getResources().getDrawable(R.drawable.ic_baseline_android);
    }

    public static boolean isSystemApp(PackageManager packageManager, String packageName) {
        boolean isSystemApp = false;
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(packageName, 0);
            if (applicationInfo != null) {
                isSystemApp = (applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        || (applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;

            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return isSystemApp;
    }

    public static boolean isInstalled(PackageManager packageManager, String packageName) {
        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = packageManager.getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return applicationInfo != null;
    }
    public static List<UsageStats>  loadApps(Context context) {
         List<UsageStats> appsUsageStats =(( UsageStatsManager)context.getSystemService(USAGE_STATS_SERVICE)).queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                System.currentTimeMillis() - 1000 * 3600 * 24,
                System.currentTimeMillis()
        );


        return appsUsageStats.stream().filter((app)->app.getTotalTimeInForeground() > 0).collect(Collectors.toList());

    }

    public static Long getTotalForeGroundTimeForSpecificApp(String appPackageName, Context context){
        List<UsageStats> appsUsageStats =(( UsageStatsManager)context.getSystemService(USAGE_STATS_SERVICE)).queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                System.currentTimeMillis() - 1000 * 3600 * 24,
                System.currentTimeMillis()
        );

        List<UsageStats> tempList = appsUsageStats.stream().filter((app)->app.getTotalTimeInForeground() > 0 && app.getPackageName().equals(appPackageName)).collect(Collectors.toList());
        if (tempList.size() > 0){
            return  tempList.get(0).getTotalTimeInForeground();
        }
        return 0L;
    }

    public static String getCurrentForeGroundApp(Context appContext){
        if (appContext == null){
            Log.e("Background app", "Context is null");
        }else {
            Log.e("Background app", "Context is not null");
        }
        String currentApp = "NULL";
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager usm = (UsageStatsManager) appContext.getSystemService(USAGE_STATS_SERVICE);
            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,  time - 1000*1000, time);
            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if (mySortedMap != null && !mySortedMap.isEmpty()) {
                    currentApp = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                }
            }
        } else {
            ActivityManager am = (ActivityManager)appContext.getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> tasks = am.getRunningAppProcesses();
            currentApp = tasks.get(0).processName;
        }

        Log.e("Background App", "Current App in foreground is: " + currentApp);
        return currentApp;
    }
}

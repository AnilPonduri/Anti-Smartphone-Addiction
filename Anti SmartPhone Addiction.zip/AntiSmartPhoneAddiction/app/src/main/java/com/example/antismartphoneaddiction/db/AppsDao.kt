package com.example.antismartphoneaddiction.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.antismartphoneaddiction.model.App

@Dao
interface AppsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(dbAppItem: DbAppItem)
//
//    @Query("SELECT upTime FROM  db_app_item WHERE appPackageName= :packageName")
//    suspend fun getAppTime(packageName:String):Long

    @Query("SELECT * FROM db_app_item")
    fun getAllUptimes(): LiveData<List<DbAppItem>>
}